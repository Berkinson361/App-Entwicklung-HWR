package com.example.appentwicklung;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.appentwicklung.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class ZielKalenderActivity extends AppCompatActivity {

    CalendarView calendarView;
    TextView selectedDateView;
    EditText zielInput;
    Button speichernButton;

    String selectedDate = "";

    Map<String, String> zieleMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ziel_kalender);

        calendarView = findViewById(R.id.calendarView);
        selectedDateView = findViewById(R.id.textViewSelectedDate);
        zielInput = findViewById(R.id.editTextTagesziel);
        speichernButton = findViewById(R.id.buttonZielSpeichern);

        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
        selectedDate = sdf.format(new Date(calendarView.getDate()));
        selectedDateView.setText("Ausgewähltes Datum: " + selectedDate);

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            Calendar cal = Calendar.getInstance();
            cal.set(year, month, dayOfMonth);
            selectedDate = sdf.format(cal.getTime());
            selectedDateView.setText("Ausgewähltes Datum: " + selectedDate);
            zielInput.setText(zieleMap.getOrDefault(selectedDate, ""));
        });

        speichernButton.setOnClickListener(v -> {
            String zielText = zielInput.getText().toString();
            zieleMap.put(selectedDate, zielText);
            Toast.makeText(this, "Ziel für " + selectedDate + " gespeichert!", Toast.LENGTH_SHORT).show();
        });
    }
}
