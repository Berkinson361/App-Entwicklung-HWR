package com.example.appentwicklung;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.appentwicklung.R;

public class RegisterActivity extends AppCompatActivity {

    EditText newUsername, newPassword, confirmPassword;
    Button finishRegisterButton;

    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        newUsername = findViewById(R.id.editTextNewUsername);
        newPassword = findViewById(R.id.editTextNewPassword);
        confirmPassword = findViewById(R.id.editTextConfirmPassword);
        finishRegisterButton = findViewById(R.id.buttonFinishRegister);

        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);

        finishRegisterButton.setOnClickListener(v -> {
            String username = newUsername.getText().toString();
            String password = newPassword.getText().toString();
            String confirm = confirmPassword.getText().toString();

            if (!password.equals(confirm)) {
                Toast.makeText(this, "Passwörter stimmen nicht überein", Toast.LENGTH_SHORT).show();
                return;
            }

            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("username", username);
            editor.putString("password", password);
            editor.apply();

            Toast.makeText(this, "Registrierung erfolgreich", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
