package com.example.appentwicklung;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class EingabeActivity extends AppCompatActivity {

    TextView welcomeText;
    EditText nameInput, zielInput;
    DatePicker datePicker;
    Button weiterButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        welcomeText = findViewById(R.id.textViewWelcome);
        nameInput = findViewById(R.id.editTextName);
        zielInput = findViewById(R.id.editTextZiel);
        datePicker = findViewById(R.id.datePicker);
        weiterButton = findViewById(R.id.buttonWeiter);

        String username = getIntent().getStringExtra("username");
        if (username != null && !username.isEmpty()) {
            welcomeText.setText("Willkommen, " + username + "!");
        } else {
            welcomeText.setText("Willkommen!");
        }

        weiterButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, ZielKalenderActivity.class);
            startActivity(intent);
        });
    }
}
